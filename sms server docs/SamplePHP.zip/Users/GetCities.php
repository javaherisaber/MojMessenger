<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/users.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['provinceId'] = 111111;


$output = $sms_client ->GetCities($parameters)->GetCitiesResult->City;

var_dump($output);
?>