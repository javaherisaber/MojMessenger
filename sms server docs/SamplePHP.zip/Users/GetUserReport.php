<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/users.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "Username";
$parameters['password'] = "Password";

echo "
<table border='1'>
<tr>
<th>Parameter</th>
<th>value</th>
</tr>";

echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->SentCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->FailedCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->SuccessCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->ReceiveCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->AlertCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->LoginCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->LastLogin . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->SumPayment . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->EmployeeCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->ContactCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->GroupCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->ScheduledCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->ForwardCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->ReplyCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->FilterCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->EmailCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->UrlCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->VoteCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->TicketCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->QuickTextCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->FromMobileCount . "</td>";
echo "<br>";
echo "<td>" . $sms_client ->GetUserReport($parameters)->GetUserReportResult->EventsCount . "</td>";

echo "</table>";
?>
