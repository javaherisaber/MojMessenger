<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/users.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['targetUserName'] = "test";
$parameters['targetUserPassword'] = "test";
$parameters['productId'] = 17109; //get this value from management panel
$parameters['descriptions'] = "test";
$parameters['mobileNumber'] = "test";
$parameters['emailAddress'] = "4941140019886618480";
$parameters['nationalCode'] = "1111111111";
$parameters['name'] = "test";
$parameters['family'] = "test";
$parameters['corporation'] = "test";
$parameters['phone'] = "Test";
$parameters['fax'] = "test";
$parameters['address'] = "test";
$parameters['postalCode'] = "1111111111";
$parameters['certificateNumber'] = "1000";


$output = $sms_client ->AddUserWithUserNameAndPass($parameters)->AddUserWithUserNameAndPassResult;

var_dump($output);
?>