<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/users.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['name'] = "Test";
$parameters['family'] = "test";
$parameters['bankName'] = "test";
$parameters['code'] = "4941140019886618480";
$parameters['amount'] = "1000";
$parameters['cardNumber'] = "4242";


$output = $sms_client ->AddPayment($parameters)->AddPaymentResult;

echo $output;
?>