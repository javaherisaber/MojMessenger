<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/users.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";

$data  = $sms_client ->GetProvinces($parameters)->GetProvincesResult->GetProvinces;


echo "<table border='1'>
<tr>
<th>ProvinceID</th>
<th>CountryID</th>
<th>UserID</th>
<th>ProvinceName</th>
<th>NumberCount</th>
</tr>";


foreach ($data as $var) {
  	
echo "<tr>";

echo "<td>" . $var->ProvinceID . "</td>";
echo "<td>" . $var->CountryID . "</td>";
echo "<td>" . $var->UserID . "</td>";
echo "<td>" . $var->ProvinceName . "</td>";
echo "<td>" . $var->NumberCount . "</td>";

echo "</tr>";

}

echo "</table>";

?>