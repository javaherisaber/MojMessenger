﻿<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/contacts.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "Username";
$parameters['password'] = "Password";
$parameters['groupName'] = "Name of the group"; 
$parameters['Descriptions'] = "Descriptions";
$parameters['showToChilds'] = false;



echo $sms_client ->AddGroup($parameters)->AddGroupResult;
?>