<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/contacts.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['groupId'] = 1; 
$parameters['keyword'] = "test";
$parameters['from'] = 1;
$parameters['count'] = 1; 


$output = $sms_client ->GetContacts($parameters)->GetContactsResult;

var_dump($output);
?>