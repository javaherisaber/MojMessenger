<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['irancellCount'] = 10; //Irancell number count
$parameters['mtnCount'] = 0; //mtn number count 
$parameters['from'] = "1000...3000..."; //which operator you are sending from 
$parameters['text'] = "test";

$var  = $sms_client ->GetSmsPrice($parameters)->GetSmsPriceResult;

echo $var;
?>