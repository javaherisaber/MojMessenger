<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['location'] = 1; // 1 = Receive | 2 = Send | -1 = All
$parameters['from'] = ""; //Here you can choose if specific number should be selected
$parameters['index'] = 0;
$parameters['count'] = 10;

$Data  = $sms_client ->getMessages($parameters)->getMessagesResult->MessagesBL;


echo "<table border='1'>
<tr>
<th>MsgID</th>
<th>UserID</th>
<th>LinkID</th>
<th>NumberID</th>
<th>Tariff</th>
<th>MsgType</th>
<th>Body</th>
<th>Udh</th>
<th>SendDate</th>
<th>Sender</th>
<th>Receiver</th>
<th>FirstLocation</th>
<th>CurrentLocation</th>
<th>Parts</th>
<th>IsFlash</th>
<th>IsRead</th>
<th>IsUnicode</th>
<th>Credit</th>
<th>Module</th>
<th>RecCount</th>
<th>RecFailed</th>
<th>RecSuccess</th>
<th>IsMoneyBack</th>
<th>UserStepedMaster</th>
<th>UserMaster</th>
<th>MoneyBackCount</th>
<th>MoneyBackLevel</th>
</tr>";


foreach ($Data as $var) {
  	
echo "<tr>";

echo "<td>" . $var->MsgID . "</td>";
echo "<td>" . $var->UserID . "</td>";
echo "<td>" . $var->LinkID . "</td>";
echo "<td>" . $var->NumberID . "</td>";
echo "<td>" . $var->Tariff . "</td>";
echo "<td>" . $var->MsgType . "</td>";
echo "<td>" . $var->Body . "</td>";
echo "<td>" . $var->Udh . "</td>";
echo "<td>" . $var->SendDate . "</td>";
echo "<td>" . $var->Sender . "</td>";
echo "<td>" . $var->Receiver . "</td>";
echo "<td>" . $var->FirstLocation . "</td>";
echo "<td>" . $var->CurrentLocation . "</td>";
echo "<td>" . $var->Parts . "</td>";
echo "<td>" . $var->IsFlash . "</td>";
echo "<td>" . $var->IsRead . "</td>";
echo "<td>" . $var->IsUnicode . "</td>";
echo "<td>" . $var->Credit . "</td>";
echo "<td>" . $var->Module . "</td>";
echo "<td>" . $var->RecCount . "</td>";
echo "<td>" . $var->RecFailed . "</td>";
echo "<td>" . $var->RecSuccess . "</td>";
echo "<td>" . $var->IsMoneyBack . "</td>";
echo "<td>" . $var->UserStepedMaster . "</td>";
echo "<td>" . $var->UserMaster . "</td>";
echo "<td>" . $var->MoneyBackCount . "</td>";
echo "<td>" . $var->MoneyBackLevel . "</td>";

echo "</tr>";

}

echo "</table>";
?>