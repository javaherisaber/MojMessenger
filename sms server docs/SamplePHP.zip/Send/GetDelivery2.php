<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['recId'] = "4941140019886618480";


$Data  = $sms_client ->GetDelivery2($parameters)->GetDelivery2Result;

echo $Data;
?>