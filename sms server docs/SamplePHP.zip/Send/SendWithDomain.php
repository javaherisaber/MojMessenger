<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['to'] = "936...912..."; 
$parameters['from'] = "1000...3000...";
$parameters['text'] = "test";
$parameters['isflash'] = false;
$parameters['domainName'] = "test.com";


$Data  = $sms_client ->SendWithDomain($parameters)->SendWithDomainResult;

echo $Data;
?>