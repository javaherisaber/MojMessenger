﻿<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['to'] = array("912....","935...."); 
$parameters['from'] = "1000...3000...";
$parameters['text'] = "test";
$parameters['isflash'] = false;

$data  = $sms_client ->SendSimpleSMS($parameters)->SendSimpleSMSResult;

foreach ($data as $var)
{
foreach ($var as $a)
{
 switch($a) {
	
	case 0:
	     echo "نام کاربری یا رمز عبور اشتباه می باشد" . "<br />";
	     break;
	
	case 1:
	     echo "درخواست با موفقیت انجام شد" . "<br />";
	     break;
	
	case 2:
	     echo "اعتبار کافی نمی باشد" . "<br />";
	     break;
	
	case 3:
	     echo "محدودیت در ارسال روزانه" . "<br />";
	     break;
	
	case 4:
	     echo "محدودیت در حجم ارسال" . "<br />";
	     break;
	
	case 5:
	     echo "شماره فرستنده معتبر نمی باشد" . "<br />";
	     break;
		 
	case 6:
	     echo "سامانه در حال بروزرسانی می باشد" . "<br />";
	     break;
		 
	case 7:
	     echo "متن حاوی کلمه فیلتر شده می باشد" . "<br />"; 
	     break;
		 
	case 9:
	     echo "ارسال از خطوط عمومی از طریق وب سرویس امکان پذیر نمی باشد" . "<br />";
	     break;

	case 10:
	     echo "کاربر مورد نظر فعال نمی باشد" . "<br />";
	     break;	
		 
	case 11:
	     echo "ارسال نشده" . "<br />";
	     break;
		 
	case 12:
	     echo "مدارک کاربر کامل نمی باشد" . "<br />";
	     break;
 }
}
}
?>