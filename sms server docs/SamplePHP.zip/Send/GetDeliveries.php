<?php
//You should use 64-bit version of php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/send.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['recIds'] = array(4941140019886618480); //for Example
$parameters['username'] = "username";
$parameters['password'] = "password";


$Data  = $sms_client ->GetDeliveries($parameters)->GetDeliveriesResult;

foreach ($Data as $var)
{
	if ($var == 1)
		echo "رسیده به گوشی";
	else 
		echo "خطا";
}
?>