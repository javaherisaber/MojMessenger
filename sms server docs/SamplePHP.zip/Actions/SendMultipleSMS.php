﻿<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/actions.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "Username";
$parameters['password'] = "Password";
$parameters['to'] = array("912"); 
$parameters['from'] = "1000000..";
$parameters['text'] = array("test");
$parameters['isflash'] = true;
$parameters['udh'] = ""; 
$parameters['recId'] = array(0);
$parameters['status'] = 0x0;


echo $var  = $sms_client ->SendMultipleSMS($parameters)->status;
?>