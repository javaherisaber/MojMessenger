﻿<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/actions.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['from'] = "1000..."; //Sending Number
$parameters['branch'] = 111111; //Get this Parameter from GetBranches WebService Function
$parameters['bulkType'] = 1; //choose either '1' which means Random or '2' which means serial
$parameters['title'] = "TITLE";
$parameters['message'] = "text"; //Text
$parameters['rangeFrom'] = ""; //Starts from "for example 912000"
$parameters['rangeTo'] = ""; //Ends At "for example 912999"
$parameters['DateToSend'] = "2013-06-15T16:50:45"; //Date To Send Y-m-d H:i:s
$parameters['requestCount'] = 11111; //Send Count
$parameters['rowFrom'] = 0;


$var  = $sms_client ->AddBulk($parameters)->AddBulkResult;

var_dump($var);
?>