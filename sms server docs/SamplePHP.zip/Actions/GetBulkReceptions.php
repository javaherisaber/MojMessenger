<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/actions.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['bulkId'] = 11111;
$parameters['fromRows'] = 11111;

$data  = $sms_client ->GetBulkReceptions($parameters)->GetBulkReceptionsResult;

var_dump($data);
?>