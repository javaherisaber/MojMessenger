<?php
ini_set("soap.wsdl_cache_enabled", "0");
$sms_client = new SoapClient('http://87.107.121.54/post/Schedule.asmx?wsdl', array('encoding'=>'UTF-8'));

$parameters['username'] = "username";
$parameters['password'] = "password";
$parameters['to'] = "912"; 
$parameters['from'] = "1000....";
$parameters['text'] = "test";
$parameters['isflash'] = false; 
$parameters['scheduleStartDateTime'] = ; //date time
$parameters['repeatAfterDays'] = 1;
$parameters['scheduleEndDateTime'] = ; //date time

$output = $sms_client ->AddUsance($parameters)->AddUsanceResult;

var_dump($output);
?>